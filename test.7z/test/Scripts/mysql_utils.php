<?php

function mysql_fetch_value( $result, $default_value = null ) {
  if( $result ) {
    $row = $result->fetch_row();
    if( $row ) {
      return $row[0];
    }
  }
  return $default_value;
}

function mysql_fetch_once( $result, $default_value = null ) {
  if( $result ) {
    $default_value = mysql_fetch_value( $result, $default_value );
    $result->close();
  }
  return $default_value;
}

function mysql_prepare_and_execute( $conn, $query, $types , &$var1, &...$vars ) {
  $stmt = $conn->prepare( $query );
  if( !$stmt ) {
    $error = "[MySQL error]: (" . $conn->errno . ") " . $conn->error;
    exit( $error );
  }
  
  $result = null;
  if( $stmt->bind_param( $types, $var1, ...$vars ) &&
      $stmt->execute() ) {
    $result = $stmt->get_result();
  }
  $stmt->close();
  return $result;
}

?>