<?php

function get_value( $key, $default_value = null ) {
  $result = $default_value;
  if( isset( $_GET[$key] ) ) {
    $result = urldecode( $_GET[$key] );
  }
  if( isset( $_POST[$key] ) ) {
    $result = $_POST[$key];
  }
  return $result;
}

function datetime_create( $year, $month, $day, $time='00:00:00' ) {
  $datetime = new DateTime( $time );
  $datetime->setDate( $year, $month, 1 );
  $datetime->add( new DateInterval( 'P' . ( $day - 1 ) . 'D' ) );
  return $datetime;
}

function datetime_validate( $datetime, $min_datetime, $max_datetime ) {
  if( $datetime < $min_datetime ) {
    $datetime = clone $min_datetime;
  }
  if( $datetime > $max_datetime ) {
    $datetime = clone $max_datetime;
  }
  return $datetime;
}

?>