<?php

function add_user($connection, $forename, $surname, $username, $password) {
  $query = "INSERT INTO users VALUES('$forename', '$surname', '$username', '$password')";
  $result = $connection->query( $query );
  if( !$result ) {
    die( $connection->error );
  }
}

require_once 'login.php';

$connection = new mysqli($hn, $un, $pw, $db);
if( $connection->connect_error ) {
  die( $connection->connect_error );
}

$salt = array( 'qm&h*', 'pg!@7' );

$forename = 'Pauline';
$surname  = 'Jones';
$username = 'pjones';
$password = 'acrobat';

$token = hash( 'ripemd128', $salt[0] . $password . $salt[1] );

add_user( $connection, $forename, $surname, $username, $token );

?>
