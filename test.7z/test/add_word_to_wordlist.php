<?php
require_once 'login.php';

$conn = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
  
// Oh no! A connect_errno exists so the connection attempt failed!
if( $conn->connect_error ) {
  $error = "[MySQL error] Failed to connect: (" . $conn->connect_errno . ") " . $conn->connect_error;
  exit( $error );
}

// Change character set to utf8.
if( !$conn->set_charset( 'utf8' ) ) {
  $error = "[MySQL error] Failed to set utf8 mode: (" . $conn->errno . ") " . $conn->error;
  exit( $error );
}

$user = DB_USER;
if( isset( $_GET['user'] ) ) {
  $user = urldecode( $_GET['user'] );
}

$word = '';
$definition = '';
if( isset( $_GET['word_id'] ) && is_numeric( $_GET['word_id'] ) &&
    isset( $_GET['dict_id'] ) && is_numeric( $_GET['dict_id'] ) ) {
  $query = "SELECT word, definition FROM book_${_GET['dict_id']} WHERE id='${_GET['word_id']}'";
  if( $result = $conn->query( $query ) ) {
    $row = $result->fetch_row();
    $word = $row[0];
    $definition = $row[1];
    $result->close();
  }
}

$conn->close();

$row_num = max( 4, substr_count( $definition, "\n" ) + 1 );

$fname = pathinfo( __FILE__, PATHINFO_FILENAME );

echo <<< HTML_TAG
<!DOCTYPE html>
<html><head>
  <title>Add to wordlist</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="${fname}.css" />
</head><body>
  <form method="post" action="wordlist.php" accept-charset="UTF-8">
    <label for="word">Word:</label><br />
    <input type="text" id="word" name="word" size="20" value="${word}"><br />
    <label for="definition">Definition:</label><br />
    <textarea id="definition" name="definition" rows="${row_num}" >${definition}</textarea><br />
    <input type="hidden" name="user" value="${user}">
    <input type="submit" value="add">
  </form>
</body></html>

HTML_TAG;

?>
