<?php
require_once 'login.php';

function group( $words, $key_length ) {
  $groups = array();
  foreach( $words as $wd ) {
    $key = mb_substr( $wd, 0, $key_length, 'utf-8' );
    $groups[$key][] = $wd;
  }
  return $groups;
}

function get_max_group( $groups ) {
  $count = 0;
  $key = null;
  
  foreach( $groups as $k => $words ) {
    $c = count( $words );
    if( $c > $count ) {
      $count = $c;
      $key = $k;
    }
  }
  
  return $key;
}

$fname = pathinfo( __FILE__, PATHINFO_FILENAME );
$conn = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );

if( !isset($_GET['book_id']) || !is_numeric($_GET['book_id']) ) {
  $error = "book_id is not found!";
  exit( $error );
}

// Oh no! A connect_errno exists so the connection attempt failed!
if( $conn->connect_error ) {
  $error = "[MySQL error] Failed to connect: (" . $conn->connect_errno . ") " . $conn->connect_error;
  exit( $error );
}

// Change character set to utf8.
if( !$conn->set_charset('utf8') ) {
  $error = "[MySQL error] Failed to set utf8 mode: (" . $conn->errno . ") " . $conn->error;
  exit( $error );
}

$book_id = $_GET['book_id'];
$result = $conn->query( "SELECT COUNT(DISTINCT word) FROM book_${book_id}" );
if( !$result ) {
  $error = "[MySQL error] Failed to read the database: (" . $conn->errno . ") " . $conn->error;
  exit( $error );
}
$word_count = $result->fetch_row()[0];
$result->close();

$word_limit = 50;
if( isset( $_GET['word_limit'] ) && is_numeric( $_GET['word_limit'] ) ) {
  $word_limit = min( $word_limit * 20, max( $_GET['word_limit'], $word_limit ) );
}

$start_id = 0;
if( isset( $_GET['start_id'] ) && is_numeric( $_GET['start_id'] ) ) {
  $start_id = max(0, min($_GET['start_id'], $word_count - $word_limit));
}

$limit = '';
if( $word_count > $word_limit ) {
  $limit = "LIMIT ${start_id}, ${word_limit}";
}
$result = $conn->query( "SELECT DISTINCT word FROM book_${book_id} ORDER BY word ${limit}" );
$words = array();
while( $row = $result->fetch_row() ) {
  $words[] = $row[0];
}
$result->close();

$groups = group( $words, 1 );
for( $i = 0; $i < 10 && count( $groups ) < 5; $i++ ) {
  $key = get_max_group( $groups );
  $new_groups = group( $groups[$key], strlen($key) + 1 );
  unset( $groups[$key] );
  foreach( $new_groups as $k => $ws ) {
    $groups[$k] = $ws;
  }
}

$dl = '';
foreach( $groups as $key => $wds ) {
  $key = htmlentities( $key );
  $dl .= <<< HTML_TAG
    <dt>${key}</dt>
    <label><input class="hidden" type="checkbox" />
    <p class="plus unchecked">&plusb;</p>
    <p class="minus checked">&minusb;</p>

HTML_TAG;
  foreach( $wds as $word ) {
    $link = urlencode( $word );
    $word = htmlentities( $word );
    $dl .= <<< HTML_TAG
    <dd class="checked"><a href="dictionary_3.php?search-input=${link}">${word}</a></dd>

HTML_TAG;
  }
  $dl .= <<< HTML_TAG
    </label>

HTML_TAG;

}


$out = <<< HTML_TAG
  <dl>
${dl}
  </dl>

HTML_TAG;

$next_id = $start_id + count($words);
if( $next_id < $word_count ) {
  $out .= <<< HTML_TAG
  <a href="${fname}.php?book_id=${book_id}&start_id=${next_id}&word_limit=${word_limit}" >next</a>

HTML_TAG;
}

echo <<< HTML_TAG
<!DOCTYPE html>
<html><head>
  <title>Word index</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="${fname}.css" />
</head><body>
${out}
</body></html>

HTML_TAG;

?>
