<?php
require_once 'login.php';

$fname = pathinfo( __FILE__, PATHINFO_FILENAME );

$conn = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
  
// Oh no! A connect_errno exists so the connection attempt failed!
if( $conn->connect_error ) {
  $error = "[MySQL error] Failed to connect: (" . $conn->connect_errno . ") " . $conn->connect_error;
  exit( $error );
}

// Change character set to utf8.
if( !$conn->set_charset('utf8') ) {
  $error = "[MySQL error] Failed to set utf8 mode: (" . $conn->errno . ") " . $conn->error;
  exit( $error );
}

$result = $conn->query( 'SELECT id, name, info FROM books ORDER BY id' );
if( !$result ) {
  $error = "[MySQL error] Failed to read the database: (" . $conn->errno . ") " . $conn->error;
  exit( $error );
}

$table = '';
while( $row = $result->fetch_assoc() ) {
  $book_id   = htmlentities( $row['id'] );
  $book_name = htmlentities( $row['name'] );
  $book_info = htmlentities( trim( $row['info'] ) );
  
  $table .= <<< HTML_TAG
    <tr>
      <td>${book_id}</td>
      <td><a href="book_index.php?book_id=${book_id}">${book_name}</a></td>
      <td><pre>${book_info}</pre></td>
    </tr>

HTML_TAG;
}

$out = <<< HTML_TAG
  <table>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Description</th>
    </tr>
${table}
  </table>

HTML_TAG;


echo <<< HTML_TAG
<!DOCTYPE html>
<html><head>
  <title>Bookshelf</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="${fname}.css" />
</head><body>
${out}
</body></html>

HTML_TAG;

?>
