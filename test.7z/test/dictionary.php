<?php
require_once 'login.php';

$debug = '';

function sanitize( $string ) {
  $string = stripcslashes( $string );
  $string = strip_tags( $string );
  $string = htmlentities( $string );
  return $string;
}

function add_html_tag($source, $search, $tag_open, $tag_close) {
  $replace = $tag_open . $search . $tag_close;
  return str_replace($search, $replace, $source);
}

function form_line($word, $info) {
  $result = '';
  // Split string by white spaces.
  $words = preg_split("#\s+#", $info, 0, PREG_SPLIT_NO_EMPTY);
  for( $i = 0; $i < count($words); $i++ ) {
    if( strstr($words[$i], '~') ) {
      $result .= '<mark>' . htmlentities(str_replace('~', $word, $words[$i]))  . '</mark>';
    } elseif($words[$i] == 'n.') {
      $result .= '<abbr title="noun">' . htmlentities($words[$i]) . '</abbr>';
    } else {
      $result .= htmlentities($words[$i]);
    }
    $result .= ' ';
  }
  return $result;
}

function get_dictionary_array( $conn, $word ) {
  $arr = array();
  if( $stmt = $conn->prepare("SELECT dict_id,word_id FROM words WHERE word LIKE ?") ) {
    $stmt->bind_param("s", $word);
    $stmt->execute();
    
    $result = $stmt->get_result();
    while( $row = $result->fetch_array(MYSQLI_NUM) ) {
      if(is_numeric($row[0]) && is_numeric($row[1])) {
        // create an array
        if( !array_key_exists($row[0], $arr) ) {
          $arr[$row[0]] = array();
        }
        $arr[$row[0]][] = $row[1];
      }
    }
    $stmt->close();
  }
  return $arr;
}

function get_word_definition( $conn, $dict_id, $word_id ) {
  $ret = '';
  global $debug;
  $debug .= ($dict_id.",".$word_id."<br />");

  if( $stmt = $conn->prepare("SELECT word, definition FROM book_$dict_id WHERE id=?") ) {
    $stmt->bind_param("i", $word_id);
    $stmt->execute();
    $stmt->bind_result($word, $desc);
    $stmt->fetch();
    
    $stmt->close();
    
    //$desc = str_replace('~', "<mark>$word</mark>", $desc);
    $desc = explode("\n", $desc);
    //$desc = add_html_tag($desc, $word, '<mark>', '</mark>');
    
    $ret =
<<< HTML_TAG
<dt class="word_dt" id="dt_${dict_id}_${word_id}">$word</dt>

HTML_TAG;

    $dd_tag_open = false;
    $lb_tag_open = false;
    for( $i = 0; $i < count($desc); $i++ ) {
      if( strlen($desc[$i]) < 1 ) {
        continue;
      }

      if( $desc[$i][0] != "\t" ) {
        if( $lb_tag_open ) {
          $ret .=
<<< HTML_TAG
</label>

HTML_TAG;
          $lb_tag_open = false;
        }

        if( $dd_tag_open ) {
          $ret .=
<<< HTML_TAG
</dd>

HTML_TAG;
          $dd_tag_open = false;
        }
        $text = form_line($word, $desc[$i]);
        $ret .=
<<< HTML_TAG
<dd class="word_dd" id="dd_${dict_id}_${word_id}_${i}">$text
HTML_TAG;
        $dd_tag_open = true;
      } else {
        $text = form_line($word, $desc[$i]);

        if( !$lb_tag_open ) {
          $lb_tag_open = true;
          $ret .=
<<< HTML_TAG
<label>
<input class="hidden" type="checkbox" />
<p class="plus unchecked">&plusb;</p>
<p class="minus checked">&minusb;</p>

HTML_TAG;
        }

        $ret .=
<<< HTML_TAG
<blockquote class="quote_dd checked" id="dd_${dict_id}_${word_id}_${i}">$text</blockquote>
HTML_TAG;
      }
    }
    if( $lb_tag_open ) {
      $ret .=
<<< HTML_TAG
</label>

HTML_TAG;
    }

    if( $dd_tag_open ) {
      $ret .=
<<< HTML_TAG
</dd>

HTML_TAG;
    }
  }
  return $ret;
}

$word = '';
$out ='';

if( isset( $_POST['search-input'] ) and $word = sanitize( $_POST['search-input'] ) ) {
  $conn = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
  
  // Oh no! A connect_errno exists so the connection attempt failed!
  if( $conn->connect_error ) {
    die( $conn->connect_error );
  }
  
  // Change character set to utf8.
  if( !$conn->set_charset('utf8') ) {
    die( $conn->error );
  }
  
  foreach(get_dictionary_array( $conn, $word ) as $dict_id => $values) {
    $out .=
<<< HTML_TAG
<div class="book_name" id="book_$dict_id">$dict_id</div>
<dl class="word_dl" id="word_dl_$dict_id">

HTML_TAG;

    for($i = 0; $i < count($values); $i++) {
      $out .= get_word_definition( $conn, $dict_id, $values[$i] );
    }
    
    $out .=
<<< HTML_TAG
</dl>

HTML_TAG;
  }
    /*//
    if( $stmt->bind_param("s", $word) && $stmt->execute() ) {
      $result = $stmt->get_result();
      if( $result->num_rows === 0 ) {
        $out = "There are no results for: '$word', sorry about that. Please try again.";
      } else {
        while ($row = $result->fetch_array(MYSQLI_NUM)) {
          $book_id = 'book_' . $row[0];
          $word_id = $row[1];
          $debug = "line3";
          if( $stmt2 = $conn->prepare("SELECT word,definition FROM ? WHERE id='?'") ){
            $debug = "line1";
            if( $stmt2->bind_param("si", $book_id, $word_id) && $stmt2->execute()
              && $stmt2->bind_result($w, $d)) {
                $debug = "line2";
              $out .= <<< HTML_TAG
<p>
$w<br>
$d
</p>

HTML_TAG;

            }
            
            $stmt2->close();
          }
        }
      }
    }
    //*/
    
    //$out = $word . ' ' . $book;
  
  // The script will automatically free the result and close the MySQL
  // connection when it exits, but let's just do it anyways
  $conn->close();
}

echo <<< HTML_TAG
<html><head>
  <title>Find the defininition of words</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <style>
label {
  border : 1px solid grey;
  border-radius: 6px; cursor: pointer;
  background-color: #def; display: block;
  width: 60%;
}

input ~ p.unchecked {
  display:inline;
}

input:checked ~ p.unchecked {
  display:none;
}

input ~ .checked {
  display:none;
}

input:checked ~ p.checked {
  display:inline;
}

input:checked ~ blockquote.checked {
  display:block;
}
input.hidden {
  display:none;
}

p.checked, p.unchecked {
  margin-bottom:0;
}

blockquote {
  margin-top:0;
  margin-bottom:0;
}

blockquote:last-child {
  margin-bottom:0.5em;
}
  </style>
</head><body>
  <form method="post" action="dictionary.php">
    <input type="text" name="search-input" size="20" value="$word">
    <input type="submit" value="search">
  </form>
$out
  <p>$debug</p>
</body></html>

HTML_TAG;

?>
