<?php
require_once 'login.php';

$debug = '';

function sanitize( $string ) {
  $string = stripcslashes( $string );
  $string = strip_tags( $string );
  $string = htmlentities( $string );
  return $string;
}

function add_html_tag($source, $search, $tag_open, $tag_close) {
  $replace = $tag_open . $search . $tag_close;
  return str_replace($search, $replace, $source);
}

function form_line($word, $info) {
  $result = '';
  // Split string by white spaces.
  $words = preg_split("#\s+#", $info, 0, PREG_SPLIT_NO_EMPTY);
  for( $i = 0; $i < count($words); $i++ ) {
    if( strstr($words[$i], '~') ) {
      $result .= '<mark>' . htmlentities(str_replace('~', $word, $words[$i]))  . '</mark>';
    } elseif($words[$i] == 'n.') {
      $result .= '<abbr title="noun">' . htmlentities($words[$i]) . '</abbr>';
    } else {
      $result .= htmlentities($words[$i]);
    }
    $result .= ' ';
  }
  return $result;
}

function get_dictionary_array( $conn, $word ) {
  $arr = array();
  if( $stmt = $conn->prepare("SELECT dict_id,word_id FROM words WHERE word LIKE ?") ) {
    $stmt->bind_param("s", $word);
    $stmt->execute();
    
    $result = $stmt->get_result();
    while( $row = $result->fetch_array(MYSQLI_NUM) ) {
      if(is_numeric($row[0]) && is_numeric($row[1])) {
        // create an array
        if( !array_key_exists($row[0], $arr) ) {
          $arr[$row[0]] = array();
        }
        $arr[$row[0]][] = $row[1];
      }
    }
    $stmt->close();
  }
  return $arr;
}

function add_tag_at( &$array, $offset, $tag ) {
  if( !array_key_exists( $offset, $array ) ) {
    $array[$offset] = array();
  }
  $array[$offset][] = $tag;
}

function get_word_definition( $conn, $dict_id, $word_id ) {
  $ret = '';
  global $debug;
  $debug .= ($dict_id.",".$word_id."<br />");

  if( $stmt = $conn->prepare("SELECT word, definition FROM book_$dict_id WHERE id=?") ) {
    $stmt->bind_param("i", $word_id);
    $stmt->execute();
    $stmt->bind_result($word, $desc);
    $stmt->fetch();
    
    $stmt->close();
    
    $ret =
<<< HTML_TAG
<dt class="word_dt" id="dt_${dict_id}_${word_id}">$word</dt>

HTML_TAG;

    
    //$desc = str_replace('~', "<mark>$word</mark>", $desc);
    $matches = array();
    $pattern = '#[^\n\r]+#';
    preg_match_all($pattern, $desc, $matches, PREG_OFFSET_CAPTURE);
    
    $tag_array = array();
    $matches = $matches[0];
    
    $dd_tag_opened = false;
    $lb_tag_opened = false;
    for( $i = 0; $i < count($matches); $i++ ) {
      $line = $matches[$i][0];
      $offset = $matches[$i][1];
      
      if( $line[0] != "\t" ) {
        if( $lb_tag_opened ) {
          add_tag_at( $tag_array, $offset, '</label>' );
          $lb_tag_opened = false;
        }
        if( $dd_tag_opened ) {
          add_tag_at( $tag_array, $offset, '</dd>' );
          $dd_tag_opened = false;
        }
        add_tag_at( $tag_array, $offset, '<dd>' );
        $dd_tag_opened = true;
      } else {
        if( !$lb_tag_opened ) {
          add_tag_at( $tag_array, $offset, '<label><input class="hidden" type="checkbox" /><p class="plus unchecked">&plusb;</p><p class="minus checked">&minusb;</p>' );
          $lb_tag_opened = true;
        }
        add_tag_at( $tag_array, $offset, '<blockquote class="checked">' );
        add_tag_at( $tag_array, $offset + strlen($line), '</blockquote>' );
      }
    }
    if( $lb_tag_opened ) {
      add_tag_at( $tag_array, strlen($desc), '</label>' );
    }
    if( $dd_tag_opened ) {
      add_tag_at( $tag_array, strlen($desc), '</dd>' );
    }
    
    $start = 0;
    $keys = array_keys( $tag_array );
    sort( $keys );
    foreach( $keys as $offset ) {
      if( $start < $offset ) {
        $ret .= htmlentities( trim( substr( $desc, $start, $offset - $start ) ) );
        $start = $offset;
      }
      foreach( $tag_array[ $offset ] as $tag ) {
        $ret .= "\n" . $tag;
      }
    }
  }
  return $ret;
}

$word = '';
$out ='';

if( isset( $_POST['search-input'] ) and $word = sanitize( $_POST['search-input'] ) ) {
  $conn = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
  
  // Oh no! A connect_errno exists so the connection attempt failed!
  if( $conn->connect_error ) {
    die( $conn->connect_error );
  }
  
  // Change character set to utf8.
  if( !$conn->set_charset('utf8') ) {
    die( $conn->error );
  }
  
  foreach(get_dictionary_array( $conn, $word ) as $dict_id => $values) {
    $out .=
<<< HTML_TAG
<div class="book_name" id="book_$dict_id">$dict_id</div>
<dl class="word_dl" id="word_dl_$dict_id">

HTML_TAG;

    for($i = 0; $i < count($values); $i++) {
      $out .= get_word_definition( $conn, $dict_id, $values[$i] );
    }
    
    $out .=
<<< HTML_TAG
</dl>

HTML_TAG;
  }
    /*//
    if( $stmt->bind_param("s", $word) && $stmt->execute() ) {
      $result = $stmt->get_result();
      if( $result->num_rows === 0 ) {
        $out = "There are no results for: '$word', sorry about that. Please try again.";
      } else {
        while ($row = $result->fetch_array(MYSQLI_NUM)) {
          $book_id = 'book_' . $row[0];
          $word_id = $row[1];
          $debug = "line3";
          if( $stmt2 = $conn->prepare("SELECT word,definition FROM ? WHERE id='?'") ){
            $debug = "line1";
            if( $stmt2->bind_param("si", $book_id, $word_id) && $stmt2->execute()
              && $stmt2->bind_result($w, $d)) {
                $debug = "line2";
              $out .= <<< HTML_TAG
<p>
$w<br>
$d
</p>

HTML_TAG;

            }
            
            $stmt2->close();
          }
        }
      }
    }
    //*/
    
    //$out = $word . ' ' . $book;
  
  // The script will automatically free the result and close the MySQL
  // connection when it exits, but let's just do it anyways
  $conn->close();
}

/*//
//self name with file extension
echo basename(__FILE__) . '<br>';
//self name without file extension
echo basename(__FILE__, '.php') . '<br>';
//self full url with file extension
echo __FILE__ . '<br>';

//parent file parent folder name
echo basename($_SERVER["REQUEST_URI"]) . '<br>';
//parent file parent folder name with //s
echo $_SERVER["REQUEST_URI"] . '<br>';

// parent file name without file extension
echo basename($_SERVER['PHP_SELF'], ".php") . '<br>';
// parent file name with file extension
echo basename($_SERVER['PHP_SELF']) . '<br>';
// parent file relative url with file etension
echo $_SERVER['PHP_SELF'] . '<br>';

// parent file name without file extension
echo basename($_SERVER["SCRIPT_FILENAME"], '.php') . '<br>';
// parent file name with file extension
echo basename($_SERVER["SCRIPT_FILENAME"]) . '<br>';
// parent file full url with file extension
echo $_SERVER["SCRIPT_FILENAME"] . '<br>';

//self name without file extension
echo pathinfo(__FILE__, PATHINFO_FILENAME) . '<br>';
//self file extension
echo pathinfo(__FILE__, PATHINFO_EXTENSION) . '<br>';

// parent file name with file extension
echo basename($_SERVER['SCRIPT_NAME']);
//*/

$script_name = basename(__FILE__);

echo <<< HTML_TAG
<!DOCTYPE html>
<html><head>
  <title>Find the defininition of words</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <style>
label {
  border : 1px solid grey;
  border-radius: 6px; cursor: pointer;
  background-color: #def; display: block;
  width: 60%;
}

input ~ p.unchecked {
  display:inline;
}

input:checked ~ p.unchecked {
  display:none;
}

input ~ .checked {
  display:none;
}

input:checked ~ p.checked {
  display:inline;
}

input:checked ~ blockquote.checked {
  display:block;
}
input.hidden {
  display:none;
}

p.checked, p.unchecked {
  margin-bottom:0;
}

blockquote {
  margin-top:0;
  margin-bottom:0;
}

blockquote:last-child {
  margin-bottom:0.5em;
}
  </style>
</head><body>
  <form method="post" action="$script_name">
    <input type="text" name="search-input" size="20" value="$word">
    <input type="submit" value="search">
  </form>
$out
  <p>$debug</p>
</body></html>

HTML_TAG;

?>
