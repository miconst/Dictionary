<?php
require_once 'login.php';
require_once 'Scripts/utils.php';
require_once 'Scripts/mysql_utils.php';

class Segment {
  // properties:
  public $start;
  public $end;
  
  function __construct($start, $end) {
    $this->start = min($start, $end);
    $this->end   = max($start, $end);
  }
  
  public function in($point) {
    return $this->start <= $point && $point <= $this->end;
  }
  
  public function intersect($other) {
    return $this->in($other->start) || $this->in($other->end);
  }
  
  public function contain($other) {
    return $this->in($other->start) && $this->in($other->end);
  }
}

class XElement extends Segment {
  public $opening_tag;
  public $closing_tag;
  public $children;
    
  function __construct($start, $end, $opening_tag, $closing_tag) {
    parent::__construct($start, $end);
    $this->opening_tag = $opening_tag;
    $this->closing_tag = $closing_tag;
    $this->children = array();
  }
  
  public function toString($text) {
    $result = $this->opening_tag;
    
    $start = $this->start;
    for($i = 0; $i < count($this->children); $i++) {
      $child = $this->children[$i];
      $result .= htmlentities(substr($text, $start, $child->start - $start));
      
      $result .= $child->toString($text);
      $start = $child->end;
    }
    
    $result .= htmlentities(substr($text, $start, $this->end - $start));
    $result .= $this->closing_tag;
    
    return $result;
  }
  
  // Try to push a new child into the existing one.
  public function addGrandchild($xelement, $inside=false) {
    for($i = count($this->children); $i --> 0;) {
      if($this->children[$i]->addChild($xelement, $inside)) {
        return true; // done
      }
    }
  }
  
  // Try to get rid of as many children as possible.
  public function donateChildren($xelement, $inside=false) {
    $donate_num = 0;
    for($i = count($this->children); $i --> 0;) {
      if($xelement->addChild($this->children[$i], $inside)) {
        // It's not our child any more.
        array_splice($this->children, $i, 1);
        $donate_num++;
      }
    }
    return $donate_num;
  }
  
  public function addChild($xelement, $inside=false) {
    if($this->contain($xelement)) {
      if($inside && $this->addGrandchild($xelement, $inside)) {
        return true;
      }
      
      $this->donateChildren($xelement, $inside);
      
      if(!$inside && $this->addGrandchild($xelement, $inside)) {
        return true;
      }
      
      // Welcome to the family.
      $this->children[] = $xelement;
      $this->sort();
      return true;
    }
  }
  
  function sort() {
    usort($this->children, array("XElement", "cmp"));
  }
  
  static function cmp($a, $b) {
    return $a->start - $b->start;
  }
}

$script_name = basename(__FILE__);
$debug = '';

function sanitize( $string ) {
  $string = urldecode( $string );
  $string = stripcslashes( $string );
  $string = strip_tags( $string );
  //$string = htmlentities( $string );
  return $string;
}

function get_dictionary_array( $conn, $word, $regexp_search=false ) {
  $search_method = 'LIKE';
  if( $regexp_search ) {
    $search_method = 'REGEXP';
  }
  $arr = array();
  if( $stmt = $conn->prepare("SELECT dict_id,word_id FROM words WHERE word ${search_method} ? LIMIT 50") ) {
    $stmt->bind_param("s", $word);
    $stmt->execute();
    
    $result = $stmt->get_result();
    while( $result && $row = $result->fetch_array(MYSQLI_NUM) ) {
      if( is_numeric($row[0]) && is_numeric($row[1]) ) {
        $arr[$row[0]][] = $row[1];
      }
    }
    $stmt->close();
  }
  return $arr;
}

function get_keyword_array( $conn, $dict_id ) {
  $arr = array();
  if( $stmt = $conn->prepare( "SELECT pcre_pattern,opening_tag,closing_tag FROM keywords_${dict_id} ORDER BY id" ) ) {
    $stmt->execute();
    
    if( $result = $stmt->get_result() ) {
      while( $row = $result->fetch_array(MYSQLI_NUM) ) {
        $arr[] = array('pcre_pattern' => $row[0], 'opening_tag' => $row[1], 'closing_tag' => $row[2]);
      }
      $result->close();
    }
    $stmt->close();
  }
  return $arr;
}

function get_word_definition( $conn, $dict_id, $word_id, $keywords ) {
  $ret = '';
  global $debug;
  global $script_name;
  
  $debug .= ($dict_id.",".$word_id."<br />");

  if( $stmt = $conn->prepare("SELECT word, definition FROM book_$dict_id WHERE id=?") ) {
    $stmt->bind_param("i", $word_id);
    $stmt->execute();
    $stmt->bind_result($word, $desc);
    $stmt->fetch();
    
    $stmt->close();
    
    $desc = str_replace('~', $word, $desc);
    
    $link = urlencode($word);
    $user = urlencode(DB_USER);

    $ret =
<<< HTML_TAG
  <dt class="word_dt dropdown" id="dt_${dict_id}_${word_id}"><a class="droplink" href="${script_name}?dict_id=${dict_id}&search-input=${link}">${word}</a>
    <div class="dropdown-content">
      <a href="add_word_to_wordlist.php?user=${user}&word_id=${word_id}&dict_id=${dict_id}">Add to my wordlist</a>
      <a href="https://www.google.com/search?q=${link}" target="_blank">Ask Google</a>
      <a href="http://dictionary.cambridge.org/dictionary/english/${link}" target="_blank">Ask Cambridge</a>
      <a href="https://translate.google.com/#en/ru/${link}" target="_blank">Translate</a>
    </div>
  </dt>
HTML_TAG;

    $xelements = new XElement(0, strlen($desc), '', '');

    $start = 0;
    $pattern = '#\n(?=[^\t])#'; // paragraph pattert
    if(preg_match_all($pattern, $desc, $matches, PREG_OFFSET_CAPTURE) > 0) {
      $matches = $matches[0];
    
      for($i = 0; $i < count($matches); $i++) {
        $offset = $matches[$i][1];
        $xelements->addChild(new XElement($start, $offset, '<dd>', '</dd>'));
        $start = $offset + 1;
      }
    }
    $xelements->addChild(new XElement($start, $xelements->end, '<dd>', '</dd>'));
    
    $pattern = '#^\t[^\n]+$#m'; // example pattern
    if(preg_match_all($pattern, $desc, $matches, PREG_OFFSET_CAPTURE) > 0) {
      $matches = $matches[0];
      for($i = 0; $i < count($matches); $i++) {
        $xelements->addChild(new XElement($matches[$i][1], $matches[$i][1] + strlen($matches[$i][0]),
          '<blockquote class="checked">', '</blockquote>'));
      }
    }
    
    // Create labels.
    foreach($xelements->children as $child) {
      $len = count($child->children);
      if($len > 0) {
        $xel = new XElement(
          $child->children[0]->start,
          $child->children[$len - 1]->end,
          '<label><input class="hidden" type="checkbox" />' .
          '<p class="plus unchecked">&plusb;</p>' .
          '<p class="minus checked">&minusb;</p>',
          '</label>');
        $child->addChild($xel);
      }
    }

    // $pattern = '#[[:alpha:]]*' . $word . '[[:alpha:]]*#'; // word pattern
    foreach($keywords as $kv) {
      //$debug .= htmlentities($kv['pcre_pattern']) . '<br>';
      if(preg_match_all($kv['pcre_pattern'], $desc, $matches, PREG_OFFSET_CAPTURE) > 0) {
        $matches = $matches[0];
        for($i = 0; $i < count($matches); $i++) {
          $xel = new XElement($matches[$i][1], $matches[$i][1] + strlen($matches[$i][0]),
            $kv['opening_tag'], $kv['closing_tag']);
          $xelements->addChild($xel, true);
        }
      }
    }
    
    $ret .= $xelements->toString($desc);
  }

  return $ret;
}

$use_regexp = '';
if( get_value( 'search-regexp' ) ) {
  $use_regexp = 'checked';
}

$out ='';
$word = '';

if( ( isset( $_POST['search-input'] ) and $word = sanitize( $_POST['search-input'] ) ) ||
    ( isset( $_GET['search-input'] ) and $word = sanitize( $_GET['search-input'] ) ) ) {
  $conn = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
  
  // Oh no! A connect_errno exists so the connection attempt failed!
  if( $conn->connect_error ) {
    die( $conn->connect_error );
  }
  
  // Change character set to utf8.
  if( !$conn->set_charset('utf8') ) {
    die( $conn->error );
  }
  
  foreach(get_dictionary_array( $conn, $word, $use_regexp ) as $dict_id => $values) {
    $out .=
<<< HTML_TAG
<div class="book_name" id="book_$dict_id">$dict_id</div>
<dl class="word_dl" id="word_dl_$dict_id">
HTML_TAG;

    for($i = 0; $i < count($values); $i++) {
      $keywords = get_keyword_array( $conn, $dict_id );
      $out .= get_word_definition( $conn, $dict_id, $values[$i], $keywords );
    }
    
    $out .=
<<< HTML_TAG
</dl>
HTML_TAG;
  }

  // The script will automatically free the result and close the MySQL
  // connection when it exits, but let's just do it anyways
  $conn->close();
}

/*//
//self name with file extension
echo basename(__FILE__) . '<br>';
//self name without file extension
echo basename(__FILE__, '.php') . '<br>';
//self full url with file extension
echo __FILE__ . '<br>';

//parent file parent folder name
echo basename($_SERVER["REQUEST_URI"]) . '<br>';
//parent file parent folder name with //s
echo $_SERVER["REQUEST_URI"] . '<br>';

// parent file name without file extension
echo basename($_SERVER['PHP_SELF'], ".php") . '<br>';
// parent file name with file extension
echo basename($_SERVER['PHP_SELF']) . '<br>';
// parent file relative url with file etension
echo $_SERVER['PHP_SELF'] . '<br>';

// parent file name without file extension
echo basename($_SERVER["SCRIPT_FILENAME"], '.php') . '<br>';
// parent file name with file extension
echo basename($_SERVER["SCRIPT_FILENAME"]) . '<br>';
// parent file full url with file extension
echo $_SERVER["SCRIPT_FILENAME"] . '<br>';

//self name without file extension
echo pathinfo(__FILE__, PATHINFO_FILENAME) . '<br>';
//self file extension
echo pathinfo(__FILE__, PATHINFO_EXTENSION) . '<br>';

// parent file name with file extension
echo basename($_SERVER['SCRIPT_NAME']);
//*/

$fname = pathinfo( __FILE__, PATHINFO_FILENAME );

echo <<< HTML_TAG
<!DOCTYPE html>
<html><head>
  <title>Find the defininition of words</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="${fname}.css" />
</head><body>
  <form method="post" action="${script_name}">
    <input type="text" name="search-input" size="20" value="$word">
    <label>
      <input type="checkbox" name="search-regexp" value="true" ${use_regexp}>use regular expression
    </label>
    <br />
    <input type="submit" value="search">
  </form>
${out}
  <p>${debug}</p>
</body></html>

HTML_TAG;

?>
