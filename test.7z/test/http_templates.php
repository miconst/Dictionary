<?php

html_tag = <<< HTML_TAG
<html><head>
  <title>$title</title>
  $meta
</head><body>
  $body
</body></html>

HTML_TAG;

meta_tag = <<< HTML_TAG
<meta http-equiv="Content-Type" content="$meta_content" />

HTML_TAG;



?>

?>
