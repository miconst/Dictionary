<?php

// bsmith/mysecret
// pjones/acrobat

require_once 'login.php';

$connection = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
if( $connection->connect_error ) {
  die( $connection->connect_error );
}

if( isset( $_SERVER['PHP_AUTH_USER'] ) && isset( $_SERVER['PHP_AUTH_PW'] ) ) {
  $user = mysql_entities_fix_string( $connection, $_SERVER['PHP_AUTH_USER'] );
  $pass = $_SERVER['PHP_AUTH_PW'];
  
  $query = "SELECT * FROM users WHERE username='$user'";
  $result = $connection->query( $query );
  if( !$result ) {
    die( $connection->error );
  } elseif( $result->num_rows <= 0 ) {
    die( 'Invalid username/password combination!' );
  } else {
    extract( $result->fetch_assoc() );
    $result->close();
    
    if( token( $pass ) != $password ) {
      die( 'Invalid username/password combination!' );
    }
    
    session_start();
    $_SESSION['username'] = $username;
    $_SESSION['password'] = $pass;
    $_SESSION['forename'] = $forename;
    $_SESSION['surname' ] = $surname;
    $_SESSION['ip_addr' ] = $_SERVER['REMOTE_ADDR'];
    
    echo "$forename $surname : <br>" .
      "Hi $forename, you are now logged in as '$username'. <br>";
    die( "<p><a href=continue.php>Click here to continue</a></p>" );
  }
} else {
  header('WWW-Authenticate: Basic realm="Restricted Section"');
  header('HTTP/1.0 401 Unauthorized');
  die("Please enter your username and password");
}

$connection->close();

?>