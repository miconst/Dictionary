<?php
define( 'DB_HOST', 'localhost'    );
define( 'DB_NAME', 'dictionary' );
define( 'DB_USER', 'test_user'    );
define( 'DB_PASS', '12345670'     );

function token( $word ) {
  $salt = array( 'qm&h*', 'pg!@7' );
  return hash( 'ripemd128', $salt[0] . $word . $salt[1] );
}

function mysql_fix_string( $connection, $string ) {
  if( get_magic_quotes_gpc() ) {
    $string = stripcslashes( $string );
  }
  return $connection->real_escape_string( $string );
}

function mysql_entities_fix_string( $connection, $string ) {
  return htmlentities( mysql_fix_string( $connection, $string ) );
}

?>
