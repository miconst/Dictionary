document.write("Test <br>")

function fixNames() {
	var s = ""
	document.write(fixNames.arguments)
	for( i = 0; i < fixNames.arguments.length; i++ ) {
		x = fixNames.arguments[i]
		s += x.charAt(0).toUpperCase() + x.substr(1).toLowerCase() + " "
	}
	return s.substr(0, s.length - 1)
}

document.write( fixNames("abas", "babas", "tABAs", "<br>") )


// User class
function User(forename, username, password) {
	this.forename = forename
	this.username = username
	this.password = password
	
	this.showUser = function() {
		document.write("Forename: " + this.forename + "<br>")
		document.write("Username: " + this.username + "<br>")
		document.write("Password: " + this.password + "<br>")
	}
}

user = new User( "Wolfgan", "mozart", "composer" )
user.showUser()
