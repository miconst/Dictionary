<html>
	<head>
		<title>A quick test</title>
	</head>
	<body>
		<?php
			echo 'Hello World!';
			
			$x = array('x' => true, 'y' => false);
			$y = 'x';
			if( $x[$y] ) {
				echo "01";
			}
			$y = 'y';
			if( $x[$y] ) {
				echo "02";
			}
			$y = 'z';
			if( $x[$y] ) {
				echo "03";
			}
		?>
	</body>
</html>