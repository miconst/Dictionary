<?php
function get_post( $conn, $var ) {
  if( get_magic_quotes_gpc() ) {
    $string = stripslashes($string);
  }
  return $conn->real_escape_string( $_POST[$var] );
}

$output = '';

require_once 'login.php';
$conn = new mysqli( $hn, $un, $pw, $db );
if( $conn->connect_error ) die( $conn->connect_error );

if( isset( $_POST['delete'] ) && isset( $_POST['isbn'] ) ) {
  $isbn = get_post( $conn, 'isbn' );
  $query = "DELETE FROM classics WHERE isbn='$isbn'";
  $result = $conn->query($query);
  if( !$result ) {
    $output .= "DELETE failed: $query<br>" . $conn->error . "<br><br>";
  }
}

if( isset( $_POST['author'] ) && isset( $_POST['title'] ) &&
  isset( $_POST['category'] ) && isset( $_POST['year']  ) &&
  isset( $_POST['isbn']     ) ) {
  $author = get_post( $conn, 'author' );
  $title = get_post( $conn, 'title' );
  $category = get_post( $conn, 'category' );
  $year = get_post( $conn, 'year' );
  $isbn = get_post( $conn, 'isbn' );
  $query = "INSERT INTO classics VALUES(
    '$author', '$title', '$category', '$year', '$isbn')";
  $result = $conn->query( $query );
  if( !$result ) {
    $output .= "INSERT failed: $query<br>" . $conn->error . "<br><br>";
  }
}

$output .=
<<< HTML_TAG
  <form action="test_mysql.php" method="post">
    <pre>
      Author   <input type="text" name="author" />
      Title    <input type="text" name="title" />
      Category <input type="text" name="category" />
      Year     <input type="text" name="year" />
      ISBN     <input type="text" name="isbn" />
      <input type="submit" value="ADD RECORD" />
    </pre>
  </form>

HTML_TAG;

$query = "SELECT * FROM classics";
$result = $conn->query( $query );
if( !$result ) die( $conn->error );

// $rows = $result->num_rows;
// for( $j = 0 ; $j < $rows ; $j++ ) {
  // $result->data_seek( $j );
  // echo '<strong>Author:</strong> ' . $result->fetch_assoc()['author'] . '<br>';
  // $result->data_seek($j);
  // echo '<strong>Title:</strong> ' . $result->fetch_assoc()['title'] . '<br>';
  // $result->data_seek($j);
  // echo '<strong>Category:</strong> ' . $result->fetch_assoc()['category'] . '<br>';
  // $result->data_seek($j);
  // echo '<strong>Year:</strong> ' . $result->fetch_assoc()['year'] . '<br>';
  // $result->data_seek($j);
  // echo '<strong>ISBN:</strong> ' . $result->fetch_assoc()['isbn'] . '<br><br>';
// }

while( $row = $result->fetch_array( MYSQLI_ASSOC ) ) {
  extract( $row );
  $output .=
<<< HTML_TAG
  <strong>Author:</strong> $author <br>
  <strong>Title:</strong> $title <br>
  <strong>Category:</strong> $category <br>
  <strong>Year:</strong> $year <br>
  <strong>ISBN:</strong> $isbn <br>
  <form action="test_mysql.php" method="post">
    <input type="hidden" name="delete" value="yes">
    <input type="hidden" name="isbn" value="$isbn">
    <input type="submit" value="DELETE RECORD">
  </form>
  <br>

HTML_TAG;
}

echo $output;

$result->close();
$conn->close();

?>
