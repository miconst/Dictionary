<html>
	<head>
		<title>PHP Form Upload</title>
	</head>
	<body>
		<form method='post' action='upload.php' enctype='multipart/form-data'>
			Select a JPG, GIF, PNG or TIF File:
			<input type='file' name='filename' size='40' />
			<input type='submit' name='submit' value='Upload' />
		</form>
<?php
	if( isset( $_POST['submit'] ) and $_FILES and $_FILES['filename']['tmp_name'] ) {
		$name = $_FILES['filename']['name'];
		
		$image_formats = array(
			'image/jpeg' => 'jpg',
			'image/png'  => 'png',
			'image/gif'  => 'gif',
			'image/tiff' => 'tif' );

		// Check if our file is an actual image or a fake
		$info = getimagesize( $_FILES['filename']['tmp_name'] );
		if( $info ) {
			$mime = $info['mime'];
			echo "'$name' is an image - $mime.<br />";
			
			if( isset( $image_formats[$mime] ) ) {
				$n = "image.$image_formats[$mime]";
				move_uploaded_file( $_FILES['filename']['tmp_name'], $n);
				
				echo "Uploaded image '$name' as '$n':<br />";
				echo "<img src='$n' />";
			} else {
				echo "'$name' is not an accepted image file!";
			}
		} else {
			echo "'$name' is not an image file!";
		}
	}
	
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
//print_r($_FILES);
//print_r($_POST);

?>
	</body>
</html>