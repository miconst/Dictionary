<?php
require_once 'login.php';
require_once 'Scripts/utils.php';
require_once 'Scripts/mysql_utils.php';


$conn = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
  
// Oh no! A connect_errno exists so the connection attempt failed!
if( $conn->connect_error ) {
  $error = "[MySQL error] Failed to connect: (" . $conn->connect_errno . ") " . $conn->connect_error;
  exit( $error );
}

// Change character set to utf8.
if( !$conn->set_charset( 'utf8' ) ) {
  $error = "[MySQL error] Failed to set utf8 mode: (" . $conn->errno . ") " . $conn->error;
  exit( $error );
}

$user = get_value( 'user', DB_USER );

$datetime = new DateTime();
$now_day = $datetime->format( 'd' );
$now_month = $datetime->format( 'm' );
$now_year = $datetime->format( 'Y' );

$month = get_value( 'month' );
if( !is_numeric( $month ) || $month <= 0 || $month > 12 ) {
  $month = $now_month;
}

$year = get_value( 'year' );
if( !is_numeric( $year ) || $year <= 0 || $year > 8888 ) {
  $year = $now_year;
}

if( $month != $now_month || $year != $now_year ) {
  $now_day = null; // not current month
  $datetime->setDate( $year, $month, 1 );
}

$month_s = $datetime->format( 'M' );
$days_in_month = cal_days_in_month( CAL_GREGORIAN, $month, $year );

$daylist = '<ul class="days">';
for( $d = 1; $d <= $days_in_month; $d++ ) {
  $datetime->setDate( $year, $month, $d );
  $mark = $datetime->format( 'Y-m-d' );
  
  $a = $d;
  $count = mysql_fetch_once(
    mysql_prepare_and_execute( $conn,
      "SELECT COUNT(word) FROM wordlist WHERE user=? AND mark >= '${mark} 00:00:00' AND mark <= '${mark} 23:59:59'",
      "s", $user ), 0 );
  if( $count > 0 ) {
    $a = <<< HTML_TAG
<a href="wordlist.php?user=${user}&min_year=${year}&min_month=${month}&min_day=${d}&max_year=${year}&max_month=${month}&max_day=${d}" title="${count} word(s)">${d}</a>
HTML_TAG;
  }
  
  $daylist .= "\n  <li>";
  if( $d == $now_day ) {
    $daylist .= '<span class="active">' . $a . '</span>';
  } else {
    $daylist .= $a;
  }
  $daylist .= '</li>';
}
$daylist .= "\n</ul>";

$weeklist = '<ul class="weekdays">';
for( $d = 1; $d <= 7; $d++ ) {
  $datetime->setDate( $year, $month, $d );
  $weeklist .= "\n  <li>" . $datetime->format( 'D' ) . '</li>';
}
$weeklist .= "\n</ul>";

$prev_year = $year;
$next_year = $year;

$prev_month = $month - 1;
if( $prev_month <= 0 ) {
  $prev_month = 12;
  $prev_year--;
}

$next_month = $month + 1;
if( $next_month > 12 ) {
  $next_month = 1;
  $next_year++;
}

$fname = pathinfo( __FILE__, PATHINFO_FILENAME );

$calendar = <<< HTML_TAG
<div class="month">
  <ul>
    <li class="prev"><a href="${fname}.php?year=${prev_year}&month=${prev_month}">&#10094;</a></li>
    <li class="next"><a href="${fname}.php?year=${next_year}&month=${next_month}">&#10095;</a></li>
    <li class="date">
      <span class="month">${month_s}</span>
      <span class="year">${year}</span>
    </li>
  </ul>
</div>
${weeklist}
${daylist}

HTML_TAG;

$conn->close();

echo <<< HTML_TAG
<!DOCTYPE html>
<html><head>
  <title>My Word Calendar</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="${fname}.css" />
</head><body>
${calendar}
</body></html>

HTML_TAG;

?>
