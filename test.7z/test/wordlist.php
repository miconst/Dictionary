<?php
require_once 'login.php';
require_once 'Scripts/utils.php';
require_once 'Scripts/mysql_utils.php';

$conn = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
  
// Oh no! A connect_errno exists so the connection attempt failed!
if( $conn->connect_error ) {
  $error = "[MySQL error] Failed to connect: (" . $conn->connect_errno . ") " . $conn->connect_error;
  exit( $error );
}

// Change character set to utf8.
if( !$conn->set_charset( 'utf8' ) ) {
  $error = "[MySQL error] Failed to set utf8 mode: (" . $conn->errno . ") " . $conn->error;
  exit( $error );
}

$user = get_value( 'user', DB_USER );

if( $word = get_value( 'word' ) ) {
  $definition = get_value( 'definition', '' );
  mysql_prepare_and_execute( $conn,
    "INSERT INTO wordlist(user, word, mark, definition) VALUES(?, ?, now(),?) ON DUPLICATE KEY UPDATE definition=VALUES(definition)",
    'sss', $user, $word, $definition );
}

// Get min/max dates.
$datetime_format = 'Y-m-d H:i:s';

$min_datetime = ( new DateTime() )->format( $datetime_format );
$max_datetime = mysql_fetch_once( 
  mysql_prepare_and_execute( $conn,
    "SELECT mark FROM wordlist WHERE user=? ORDER BY mark DESC LIMIT 1",
    's', $user ),
  $min_datetime );

$min_datetime = mysql_fetch_once( 
  mysql_prepare_and_execute( $conn,
    "SELECT mark FROM wordlist WHERE user=? ORDER BY mark LIMIT 1",
    's', $user ),
  $min_datetime );

$min_datetime = DateTime::createFromFormat( $datetime_format, $min_datetime );
$max_datetime = DateTime::createFromFormat( $datetime_format, $max_datetime );

$min_year  = $min_datetime->format( 'Y' );
$min_month = $min_datetime->format( 'm' );
$min_day   = $min_datetime->format( 'd' );

$max_year  = $max_datetime->format( 'Y' );
$max_month = $max_datetime->format( 'm' );
$max_day   = $max_datetime->format( 'd' );

$opening_datetime = datetime_create(
  get_value( 'min_year', $min_year ),
  get_value( 'min_month', $min_month ),
  get_value( 'min_day', $min_day ),
  '00:00:00' );
$closing_datetime = datetime_create(
  get_value( 'max_year', $max_year ),
  get_value( 'max_month', $max_month ),
  get_value( 'max_day', $max_day ),
  '23:59:59' );

$opening_datetime = datetime_validate( $opening_datetime, $min_datetime, $max_datetime );
$closing_datetime = datetime_validate( $closing_datetime, $opening_datetime, $max_datetime );

$odt = $opening_datetime->format( $datetime_format );
$cdt = $closing_datetime->format( $datetime_format );

$result = mysql_prepare_and_execute( $conn,
  "SELECT word, mark, definition FROM wordlist WHERE user=? AND mark >= '${odt}' AND mark <= '${cdt}'",
  "s", $user );

$table = '';
while( $result && $row = $result->fetch_array( MYSQLI_NUM ) ) {
  $word = htmlentities( $row[0] );
  $link = urlencode( $row[0] );
  $mark = htmlentities( $row[1] );
  $text = htmlentities( $row[2] );
  
  $play = array();
  foreach( glob( 'Pronunciation/' . $row[0] . '.*' ) as $filename ) {
    $pathinfo = pathinfo( $filename );
    
    $country = $pathinfo['filename'];
    $country = substr($country, stripos($country, '.') + 1);
    
    //$play[$country]['data-src-' . $pathinfo['extension']] = '"' . $filename . '"';
    $play[$country][] = '"' . $filename . '"';
  }
  
  $span = '';
  if( count( $play ) > 0 ) {
    foreach( $play as $country => $data_sources ) {
      $data = '';
      foreach( $data_sources as $data_path ) {
        $data .= "<source src=${data_path}>";
      }
      
      $title = "Listen to ${country} pronunciation";
      
      $id = $row[0] . '_' . $country;
      $span .= <<< HTML_TAG

        <audio id="${id}">${data}</audio>
        <button title="${title}" onclick="document.getElementById('${id}').play()">${country}</button>
HTML_TAG;
    }
  }
  
  $table .= <<< HTML_TAG
    <tr>
      <td>
        <a href="dictionary_3.php?search-input=${link}">${word}</a>${span}
      </td>
      <td><pre>${text}</pre></td>
      <td>${mark}</td>
    </tr>

HTML_TAG;
}

$result->close();
$conn->close();

$opening_year = $opening_datetime->format( 'Y' );
$closing_year = $closing_datetime->format( 'Y' );

$opening_month = $opening_datetime->format( 'm' );
$closing_month = $closing_datetime->format( 'm' );

$opening_day = $opening_datetime->format( 'd' );
$closing_day = $closing_datetime->format( 'd' );

$fname = pathinfo( __FILE__, PATHINFO_FILENAME );

$out = <<< HTML_TAG
  <input type="text" id="filter_input" onkeyup="filter_table()" placeholder="Search for words...">
  <form class="date_input" action="${fname}.php">
    <span class="date_input">From:
      <input type="number" title="Year"  class="year_input"  name="min_year"  min="${min_year}" max="${max_year}" step="1" value="${opening_year}">
      <input type="number" title="Month" class="month_input" name="min_month" min="1"           max="12"          step="1" value="${opening_month}">
      <input type="number" title="Day"   class="day_input"   name="min_day"   min="1"           max="31"          step="1" value="${opening_day}">
    </span>
    <span class="date_input">To:
      <input type="number" title="Year"  class="year_input"  name="max_year"  min="${min_year}" max="${max_year}" step="1" value="${closing_year}">
      <input type="number" title="Month" class="month_input" name="max_month" min="1"           max="12"          step="1" value="${closing_month}">
      <input type="number" title="Day"   class="day_input"   name="max_day"   min="1"           max="31"          step="1" value="${closing_day}">
      <input type="submit">
    </span>
  </form>
  <table id="filter_table">
    <tr>
      <th>Word</th>
      <th>Translation</th>
      <th>Time</th>
    </tr>
${table}
  </table>

HTML_TAG;


echo <<< HTML_TAG
<!DOCTYPE html>
<html><head>
  <title>My Wordlist</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="${fname}.css" />
  <script type="text/javascript" src="Scripts/filters.js"></script>
</head><body>
${out}
</body></html>

HTML_TAG;

?>
